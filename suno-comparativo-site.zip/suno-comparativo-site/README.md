# Comparativo de Planos Suno

Ferramenta interna do time comercial (Suno Research). Site estático de arquivo único.

- `index.html`: aplicação completa (HTML, CSS e JS inline, sem build).
- `vercel.json`: cabeçalhos de segurança e `noindex` (não aparecer em buscadores).

## Atualizar o site
1. Edite `index.html` (ou substitua pelo arquivo novo).
2. Faça commit na branch `main`.
3. O Vercel publica automaticamente em ~1 minuto.

## Preços
Os valores dos planos ficam em `DEFAULT_PRICES` dentro de `index.html`
(formato `{ idDoPlano: { mensal: 0, anual: 0 } }`, em R$). Use apenas valores oficiais.

Não versionar credenciais, tokens ou dados de clientes neste repositório.
